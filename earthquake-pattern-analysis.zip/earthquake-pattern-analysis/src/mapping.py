"""
Interactive Folium maps for earthquake catalogs.

Produces standalone HTML files you can open in a browser or embed in a GitHub
Pages site. Two views: a clustered marker map (drill down to individual events)
and a density heatmap (see the geographic clustering at a glance).
"""

from __future__ import annotations

from pathlib import Path

import folium
import numpy as np
import pandas as pd
from folium.plugins import HeatMap, MarkerCluster


def _depth_color(depth_km: float) -> str:
    """USGS-style depth coloring: shallow = red, deep = blue."""
    if depth_km is None or np.isnan(depth_km):
        return "gray"
    if depth_km < 70:
        return "#d7301f"
    if depth_km < 300:
        return "#fc8d59"
    return "#2c7fb8"


def marker_cluster_map(
    df: pd.DataFrame,
    outpath: str | Path = "outputs/earthquake_map.html",
    max_markers: int = 5000,
) -> Path:
    """
    Clustered marker map. Each marker is sized by magnitude and colored by depth;
    popups show details. Markers are capped at ``max_markers`` (largest events
    kept) so the HTML stays responsive.
    """
    outpath = Path(outpath)
    outpath.parent.mkdir(parents=True, exist_ok=True)

    plot_df = df
    if len(df) > max_markers:
        plot_df = df.nlargest(max_markers, "magnitude")
        print(f"Capping map at {max_markers:,} largest-magnitude events "
              f"(of {len(df):,}).")

    center = [plot_df["latitude"].median(), plot_df["longitude"].median()]
    fmap = folium.Map(location=center, zoom_start=2, tiles="CartoDB positron")
    cluster = MarkerCluster(name="Earthquakes").add_to(fmap)

    for _, row in plot_df.iterrows():
        radius = max(2, (row["magnitude"] ** 1.6))
        popup = folium.Popup(
            f"<b>M {row['magnitude']:.1f}</b><br>"
            f"{row.get('place', 'Unknown')}<br>"
            f"Depth: {row['depth_km']:.0f} km<br>"
            f"{row.get('datetime', '')}",
            max_width=260,
        )
        folium.CircleMarker(
            location=[row["latitude"], row["longitude"]],
            radius=radius,
            color=_depth_color(row["depth_km"]),
            fill=True,
            fill_opacity=0.7,
            weight=1,
            popup=popup,
        ).add_to(cluster)

    _add_depth_legend(fmap)
    folium.LayerControl().add_to(fmap)
    fmap.save(str(outpath))
    print(f"Saved marker map to {outpath}")
    return outpath


def heatmap(
    df: pd.DataFrame,
    outpath: str | Path = "outputs/earthquake_heatmap.html",
    weight_by_magnitude: bool = True,
) -> Path:
    """Density heatmap of epicenters, optionally weighted by magnitude."""
    outpath = Path(outpath)
    outpath.parent.mkdir(parents=True, exist_ok=True)

    fmap = folium.Map(location=[20, 0], zoom_start=2, tiles="CartoDB dark_matter")
    if weight_by_magnitude:
        data = df[["latitude", "longitude", "magnitude"]].dropna().values.tolist()
    else:
        data = df[["latitude", "longitude"]].dropna().values.tolist()

    HeatMap(data, radius=10, blur=12, min_opacity=0.3).add_to(fmap)
    fmap.save(str(outpath))
    print(f"Saved heatmap to {outpath}")
    return outpath


def _add_depth_legend(fmap: folium.Map) -> None:
    legend_html = """
    <div style="position: fixed; bottom: 30px; left: 30px; z-index: 9999;
                background: white; padding: 10px 14px; border-radius: 6px;
                font-size: 13px; box-shadow: 0 1px 4px rgba(0,0,0,0.3);">
      <b>Depth</b><br>
      <span style="color:#d7301f;">&#9679;</span> Shallow (&lt;70 km)<br>
      <span style="color:#fc8d59;">&#9679;</span> Intermediate (70-300 km)<br>
      <span style="color:#2c7fb8;">&#9679;</span> Deep (&gt;300 km)
    </div>
    """
    fmap.get_root().html.add_child(folium.Element(legend_html))

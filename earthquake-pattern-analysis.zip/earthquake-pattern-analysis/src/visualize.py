"""
Matplotlib visualizations for earthquake catalogs.

Every function takes a DataFrame (and sometimes analysis outputs) and saves a
figure to ``outdir``, returning the saved path. A shared style keeps the set
visually consistent.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from . import analysis

plt.rcParams.update(
    {
        "figure.dpi": 110,
        "savefig.dpi": 150,
        "font.size": 11,
        "axes.grid": True,
        "grid.alpha": 0.3,
        "axes.spines.top": False,
        "axes.spines.right": False,
    }
)

ACCENT = "#c1432a"
INK = "#22303f"


def _save(fig, outdir: Path, name: str) -> Path:
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    path = outdir / name
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return path


def plot_gutenberg_richter(
    df: pd.DataFrame,
    outdir: str | Path = "outputs",
    bin_width: float = 0.1,
    name: str = "gutenberg_richter.png",
) -> Path:
    """
    The headline plot: cumulative & incremental frequency-magnitude distribution
    on a log scale, with the maximum-likelihood G-R fit line and annotated
    b-value / Mc.
    """
    fmd = analysis.frequency_magnitude_distribution(df["magnitude"], bin_width)
    mc = analysis.magnitude_of_completeness(df["magnitude"], bin_width)
    mle = analysis.b_value_mle(df["magnitude"], mc=mc, bin_width=bin_width)
    lsq = analysis.b_value_lstsq(df["magnitude"], mc=mc, bin_width=bin_width)

    fig, ax = plt.subplots(figsize=(8, 6))
    ax.scatter(fmd["mag"], fmd["cumulative"], s=28, color=INK,
               label="Cumulative N (≥ M)", zorder=3)
    ax.scatter(fmd["mag"], fmd["incremental"].replace(0, np.nan), s=18,
               facecolors="none", edgecolors="gray", label="Incremental", zorder=2)

    # G-R fit line from the MLE b-value, anchored at Mc.
    mags = np.linspace(mc, fmd["mag"].max(), 100)
    log_n = mle["a"] - mle["b"] * mags
    ax.plot(mags, 10**log_n, color=ACCENT, lw=2.2,
            label=f"G-R fit: b = {mle['b']:.2f} ± {mle['b_err']:.2f}", zorder=4)

    ax.axvline(mc, color="gray", ls="--", lw=1, alpha=0.7)
    ax.annotate(f"Mc = {mc:.1f}", xy=(mc, ax.get_ylim()[0]),
                xytext=(mc + 0.1, fmd["cumulative"].max()), color="gray")

    ax.set_yscale("log")
    ax.set_xlabel("Magnitude")
    ax.set_ylabel("Number of earthquakes")
    ax.set_title("Gutenberg-Richter frequency-magnitude distribution")
    ax.legend(frameon=False)

    txt = (f"MLE  b = {mle['b']:.3f} ± {mle['b_err']:.3f}\n"
           f"LSQ  b = {lsq['b']:.3f}  (R² = {lsq['r_squared']:.3f})\n"
           f"a = {mle['a']:.2f}   N = {mle['n']:,}")
    ax.text(0.97, 0.97, txt, transform=ax.transAxes, ha="right", va="top",
            fontsize=9, family="monospace",
            bbox=dict(boxstyle="round", fc="white", ec="lightgray"))

    return _save(fig, outdir, name)


def plot_magnitude_histogram(
    df: pd.DataFrame, outdir: str | Path = "outputs",
    bin_width: float = 0.2, name: str = "magnitude_histogram.png",
) -> Path:
    fig, ax = plt.subplots(figsize=(8, 5))
    mags = df["magnitude"].dropna()
    bins = np.arange(np.floor(mags.min()), np.ceil(mags.max()) + bin_width, bin_width)
    ax.hist(mags, bins=bins, color=INK, alpha=0.85)
    ax.set_xlabel("Magnitude")
    ax.set_ylabel("Count")
    ax.set_title(f"Magnitude distribution (n = {len(mags):,})")
    return _save(fig, outdir, name)


def plot_depth_distribution(
    df: pd.DataFrame, outdir: str | Path = "outputs",
    name: str = "depth_distribution.png",
) -> Path:
    """Depth histogram plus magnitude-vs-depth scatter."""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5))

    depth = df["depth_km"].dropna()
    ax1.hist(depth, bins=40, color="#2a6f97", alpha=0.85)
    ax1.set_xlabel("Depth (km)")
    ax1.set_ylabel("Count")
    ax1.set_title("Hypocenter depth distribution")

    sc = ax2.scatter(df["depth_km"], df["magnitude"], c=df["depth_km"],
                     cmap="viridis_r", s=10, alpha=0.5)
    ax2.set_xlabel("Depth (km)")
    ax2.set_ylabel("Magnitude")
    ax2.set_title("Magnitude vs depth")
    fig.colorbar(sc, ax=ax2, label="Depth (km)")
    return _save(fig, outdir, name)


def plot_temporal(
    df: pd.DataFrame, outdir: str | Path = "outputs",
    name: str = "temporal.png",
) -> Path:
    """Daily event counts over the catalog's time span."""
    fig, ax = plt.subplots(figsize=(11, 5))
    daily = df.set_index("datetime").resample("1D").size()
    ax.plot(daily.index, daily.values, color=ACCENT, lw=1.2)
    ax.fill_between(daily.index, daily.values, color=ACCENT, alpha=0.2)
    ax.set_xlabel("Date (UTC)")
    ax.set_ylabel("Earthquakes per day")
    ax.set_title("Seismicity over time")
    fig.autofmt_xdate()
    return _save(fig, outdir, name)


def plot_global_scatter(
    df: pd.DataFrame, outdir: str | Path = "outputs",
    name: str = "global_scatter.png",
) -> Path:
    """
    Lon/lat scatter of all epicenters, sized by magnitude and colored by depth.
    A static companion to the interactive Folium map (and the clearest single
    view of where the plate boundaries are).
    """
    fig, ax = plt.subplots(figsize=(13, 7))
    sizes = np.clip((df["magnitude"] - df["magnitude"].min() + 0.5) ** 2.2, 2, 200)
    sc = ax.scatter(df["longitude"], df["latitude"], s=sizes,
                    c=df["depth_km"], cmap="plasma_r", alpha=0.55,
                    edgecolors="none")
    ax.set_xlim(-180, 180)
    ax.set_ylim(-90, 90)
    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    ax.set_title("Global earthquake epicenters (size ∝ magnitude, color = depth)")
    ax.set_aspect("equal", adjustable="box")
    fig.colorbar(sc, ax=ax, label="Depth (km)", shrink=0.7)
    return _save(fig, outdir, name)

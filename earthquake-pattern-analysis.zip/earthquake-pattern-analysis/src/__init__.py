"""Earthquake Pattern Analysis — pull USGS data, fit Gutenberg-Richter, map clusters."""

from . import analysis, data_fetch, mapping, visualize

__all__ = ["analysis", "data_fetch", "mapping", "visualize"]
__version__ = "0.1.0"

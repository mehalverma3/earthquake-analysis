"""
Tests for the Gutenberg-Richter analysis.

The key correctness check: generate a synthetic catalog from a KNOWN b-value and
confirm both estimators recover it within tolerance. Run with `pytest` or
directly with `python tests/test_analysis.py`.
"""

import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src import analysis  # noqa: E402


def synthetic_magnitudes(b=0.95, mc=4.5, n=20000, seed=42, bin_width=0.1):
    """Magnitudes drawn from the exponential implied by the G-R law, then
    rounded to the bin width to mimic real USGS reporting.

    The continuum starts at ``mc - bin_width/2`` so that the completeness bin is
    fully (symmetrically) populated -- this is what the maximum-likelihood
    estimator's ΔM/2 correction assumes, and how real binned catalogs behave.
    """
    rng = np.random.default_rng(seed)
    beta = b * np.log(10)
    raw = (mc - bin_width / 2) + rng.exponential(scale=1 / beta, size=n)
    return np.round(raw, 1)


def test_b_value_mle_recovers_truth():
    true_b = 0.95
    mags = synthetic_magnitudes(b=true_b)
    mc = analysis.magnitude_of_completeness(mags)
    result = analysis.b_value_mle(mags, mc=mc)
    assert abs(result["b"] - true_b) < 0.05, result
    assert result["b_err"] > 0


def test_b_value_lstsq_recovers_truth():
    true_b = 0.95
    mags = synthetic_magnitudes(b=true_b)
    mc = analysis.magnitude_of_completeness(mags)
    result = analysis.b_value_lstsq(mags, mc=mc)
    assert abs(result["b"] - true_b) < 0.08, result
    assert result["r_squared"] > 0.95


def test_fmd_is_monotonic_decreasing():
    mags = synthetic_magnitudes()
    fmd = analysis.frequency_magnitude_distribution(mags)
    cum = fmd["cumulative"].to_numpy()
    assert np.all(np.diff(cum) <= 0), "cumulative count must be non-increasing"
    assert fmd["incremental"].sum() == len(mags)


def test_empty_input():
    fmd = analysis.frequency_magnitude_distribution([])
    assert fmd.empty


if __name__ == "__main__":
    test_b_value_mle_recovers_truth()
    test_b_value_lstsq_recovers_truth()
    test_fmd_is_monotonic_decreasing()
    test_empty_input()
    print("All tests passed.")
